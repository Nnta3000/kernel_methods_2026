import jax.numpy as jnp
import pandas as pd
import numpy as np
from jaxtyping import Float, Array, Integer
from typing import Callable, List, Optional, Protocol, TypeVar

A = TypeVar('A')

class Kernel(Protocol[A]):
    def _null_kernel(_1: A, _2: A) -> float:
        del _1, _2
        return 0
    k: Callable[[A, A], float] = _null_kernel
    def __init__(self, k: Callable[[A, A], float], device) -> None:
        self.k = k
    def __call__(self, x: A, y: A) -> float:
        return self.k(x, y)
    def to_tensor(self, elements: List[A]) -> Float[Array, "N N"]:
        items: List[A] = list(elements)
        return jnp.array([[self.k(e1, e2) for e1 in items] for e2 in items])


class KernelDataset:
    labels: Optional[Integer[Array, "N"]] = None

    def __init__(self, x_csv_path: str, y_csv_path: Optional[str] = None):
        pixel_data = np.array(pd.read_csv(x_csv_path, header=None, sep=',', usecols=range(3072)))
        self.images: Float[Array, "N 3 32 32"] = jnp.array(pixel_data, dtype=jnp.float32).reshape(-1, 3, 32, 32)

        if y_csv_path is not None:
            labels = np.array(pd.read_csv(y_csv_path, sep=',', usecols=[1])).squeeze()
            self.labels = jnp.array(labels, dtype=jnp.int32)

    def __len__(self) -> int:
        return self.images.shape[0]

    def __getitem__(self, idx: int):
        img = self.images[idx]
        return (img, self.labels[idx]) if self.labels is not None else (img, idx)


class KernelDataLoader:
    def __init__(self, dataset: KernelDataset, kernel: Optional[Kernel] = None, batch_size: int = 64, shuffle: bool = True):
        self.dataset = dataset
        self.kernel = kernel
        self.batch_size = batch_size
        self.shuffle = shuffle

    def get_kernel_matrix(self) -> Float[Array, "N N"]:
        if self.kernel is None:
            raise ValueError("No kernel provided.")
        images: List[Float[Array, "D"]] = list(self.dataset.images.reshape(-1, 3072))
        return self.kernel.to_tensor(images)

    def __iter__(self):
        n = len(self.dataset)
        indices = np.random.permutation(n) if self.shuffle else np.arange(n)
        for i in range(0, n, self.batch_size):
            batch_idx = indices[i:i + self.batch_size]
            imgs = self.dataset.images[batch_idx]
            if self.dataset.labels is not None:
                yield imgs, self.dataset.labels[batch_idx]
            else:
                yield imgs, batch_idx
