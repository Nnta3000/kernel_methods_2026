import jax.numpy as jnp
from jaxtyping import Float, Array
import utils

class GaussianKernel(utils.Kernel):
    def __init__(self, sigma: float, device='cpu'):
        k = lambda x, y: float(jnp.exp(-jnp.sum((x - y) ** 2) / (2 * sigma ** 2)))
        super().__init__(k, device)
