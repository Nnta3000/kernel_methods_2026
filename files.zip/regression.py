from utils import Kernel
from dataclasses import dataclass
from typing import Protocol, Optional
import jax.numpy as jnp
from jaxtyping import Float, Integer, Array

@dataclass
class Regularizer:
    lam: float = 1.0


class MulticlassStrategy(Protocol):
    def fit(self, K: Float[Array, "N N"], y: Integer[Array, "N"]) -> None: ...
    def predict(self, K_test: Float[Array, "M N"]) -> Integer[Array, "M"]: ...


class KernelRidgeRegression:
    def __init__(self, regularizer: Regularizer):
        self.lam = regularizer.lam
        self.alpha: Optional[Float[Array, "N C"]] = None

    def fit(self, K: Float[Array, "N N"], y: Float[Array, "N C"]) -> None:
        n = K.shape[0]
        self.alpha = jnp.linalg.solve(K + self.lam * n * jnp.eye(n), y)

    def predict(self, K_test: Float[Array, "M N"]) -> Float[Array, "M C"]:
        if self.alpha is None:
            raise ValueError("Model not fitted yet.")
        return K_test @ self.alpha


class Classifier:
    def __init__(self, strategy: MulticlassStrategy):
        self.strategy = strategy

    def fit(self, K: Float[Array, "N N"], y: Integer[Array, "N"]) -> None:
        self.strategy.fit(K, y)

    def predict(self, K_test: Float[Array, "M N"]) -> Integer[Array, "M"]:
        return self.strategy.predict(K_test)


class OneVsAllStrategy:
    def __init__(self, n_classes: int, regularizer: Regularizer):
        self.n_classes = n_classes
        self.models = [KernelRidgeRegression(regularizer) for _ in range(n_classes)]

    def fit(self, K: Float[Array, "N N"], y: Integer[Array, "N"]) -> None:
        for c, model in enumerate(self.models):
            y_binary: Float[Array, "N"] = (y == c).astype(jnp.float32)
            model.fit(K, y_binary)

    def predict(self, K_test: Float[Array, "M N"]) -> Integer[Array, "M"]:
        scores = jnp.stack([m.predict(K_test) for m in self.models], axis=1)
        return jnp.argmax(scores, axis=1)
